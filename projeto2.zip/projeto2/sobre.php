		<?php include('header.php'); ?>
		
		<div id="corpo">
			
			
			
			<h1>Sobre Mim</h1>
			<p><strong>Nome: </strong>Antonio Marcos Soares</p>
			<p><strong>Email: </strong>marcoos_soares@hotmail.com</p>
			<p><strong>Telefone: </strong>(19) 9.9808-7035</p>
			
			<h2>Um pouco sobre mim:</h2>
			
			<p>
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque interdum eleifend libero, eu sollicitudin purus suscipit vestibulum. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec tempus dictum augue vel consequat. Suspendisse ipsum quam, feugiat a mauris ac, eleifend facilisis arcu. Sed quis ultrices ex. Pellentesque vitae nulla at est sodales sagittis. 
			</p>
			
			<p>Sed ut enim enim. Sed molestie elit quis mollis tristique. Praesent iaculis lorem vel elit scelerisque, eget porta magna vehicula. Nulla porttitor, lacus eu scelerisque fermentum, libero risus aliquam dolor, ut egestas justo nisl vel urna. Cras in urna vel nulla tempor interdum quis eu nisl. Aliquam sodales posuere ex. Sed id erat mollis, dictum dolor at, molestie dolor. In lacus mi, ullamcorper nec sollicitudin eu, porttitor ac ex. Mauris lorem massa, dapibus nec scelerisque eu, porttitor nec lorem.</p>

			<p>
Vestibulum viverra mauris venenatis urna aliquam malesuada. Fusce tristique cursus lorem ut viverra. Sed iaculis eget nunc quis posuere. Sed tristique et massa quis pharetra. Nullam velit sem, sagittis ut faucibus vehicula, feugiat at odio. Fusce purus erat, scelerisque et mauris tincidunt, rhoncus commodo tellus. Quisque molestie nec nulla dapibus vestibulum. Quisque iaculis imperdiet aliquam. Donec nec gravida nibh. Proin suscipit mollis dui non convallis. Praesent ut purus sem. Aenean a semper ante, vel gravida sem. Etiam aliquet maximus justo et ultricies. Cras sit amet neque mauris.
			</p>
			
			



			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		</div>
		
	</div>
  </div>
  
</body>
</html>