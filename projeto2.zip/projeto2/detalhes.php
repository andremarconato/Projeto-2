		<?php include('header.php'); ?>
		
		<div id="corpo">
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			<?php
			$servername = "localhost";
			$username = "ejecty_projeto";
			$password = "projeto123";
			$dbname = "ejecty_projeto";
			
			// Create connection
			$conn = mysqli_connect($servername, $username, $password, $dbname);
			// Check connection
			if (!$conn) {
			    die("Connection failed: " . mysqli_connect_error());
			}
			
			$sql = "SELECT * FROM filmes WHERE id = ".$_GET['id']." LIMIT 3";
			$result = mysqli_query($conn, $sql);
			
			if(mysqli_num_rows($result) > 0){

			    $row = mysqli_fetch_assoc($result);			      
			    echo "<h1>".$row['nome'];
			    echo "(".substr($row['lancamento'],4,4).")";
			    echo "</h1>";
			    
			    echo "<img src='".$row['imagem']."' width='100%' height='200'>";	
			    
			    echo "<p>Descricao:<br />".$row['descricao']."</p>";
			    
			    echo "<p>Ator: ".$row['ator']."</p>";
			    
			    echo "<p>Diretor: ".$row['diretor']."</p>";
			    
			    echo "<p>Bilheteria: ".$row['bilheteria']."</p>";
			    		    
			} else {
			    echo "nenhum resultado";
			}
									
			mysqli_close($conn);
			?>



			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		</div>
		
	</div>
  </div>
  
</body>
</html>