		<?php include('header.php'); ?>
		<div id="corpo">
			
			
			
			<h1>Contato</h1>
			<form action="" method="POST">
			
			<p>Nome:<br />
			<input class="caixa" type="text" name="nome" /></p>
			
			<p>Email:<br />
			<input class="caixa" type="text" name="email" /></p>
			
			<p>Telefone:<br />
			<input class="caixa" type="text" name="telefone" /></p>
			
			<p>Assunto:<br />
			<input class="caixa" type="text" name="assunto" /></p>
			
			<p>Mensagem:<br />
			<textarea class="msg" name="mensagem"></textarea></p>
			
			<input class="btn" type="submit" value="ENVIAR MENSAGEM" />
			</form>



			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		</div>
		
	</div>
  </div>
  
</body>
</html>