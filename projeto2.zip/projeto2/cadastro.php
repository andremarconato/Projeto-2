
<?php

include('header.php'); 
include('conexao.php');

if(isset($_POST['nome'])){
	$sql = "INSERT INTO filmes (nome, lancamento, descricao, ator, diretor, bilheteria, imagem)
	VALUES ('".$_POST['nome']."', '".$_POST['lancamento']."', '".$_POST['descricao']."', '".$_POST['ator']."', '".$_POST['diretor']."', '".$_POST['bilheteria']."', '".$_POST['imagem']."')";
	
	if (mysqli_query($conn, $sql)) {
	    echo "Gravado com sucesso";
	} else {
	    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
}

mysqli_close($conn);
?>


<h1>Cadastro</h1>

<form action="" method="POST">
<p>Filme:<br />
<input type="text" class="caixa" name="nome" /></p>

<p>Data de Lançamento:<br />
<input type="text" class="caixa" name="lancamento" /></p>

<p>Descricao:<br />
<input type="text" class="msg" name="descricao" /></p>

<p>Ator:<br />
<input type="text" class="caixa" name="ator" /></p>

<p>Diretor:<br />
<input type="text" class="caixa" name="diretor" /></p>

<p>Bilheteria:<br />
<input type="text" class="caixa" name="bilheteria" /></p>

<p>Imagem:<br />
<input type="text" class="caixa" name="imagem" /></p>

<input type="submit" class="btn" value="GRAVAR" />
</form>

