-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 20-Dez-2017 às 10:25
-- Versão do servidor: 5.5.51-38.2
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ejecty_projeto`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `filmes`
--

CREATE TABLE IF NOT EXISTS `filmes` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `lancamento` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8_unicode_ci NOT NULL,
  `ator` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `diretor` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `bilheteria` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `imagem` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `filmes`
--

INSERT INTO `filmes` (`id`, `nome`, `lancamento`, `descricao`, `ator`, `diretor`, `bilheteria`, `imagem`) VALUES
(2, 'Filme 01', '20122017', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur congue nisi id euismod pretium. Aliquam consequat purus eget nisl eleifend molestie. Maecenas rutrum eros urna, eu sollicitudin elit viverra eu. Donec sollicitudin rhoncus lacus, euismod suscipit est accumsan id. ', 'Ator 01', 'Diretor 01', 'Bilheteria 01', 'https://static1.squarespace.com/static/54e6020ee4b0df3d2d8e6adb/t/5505f8f1e4b0147d505bbeab/1426454772902/cottage_fall2_banner.jpg'),
(3, 'Filme 02', '20122017', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur congue nisi id euismod pretium. Aliquam consequat purus eget nisl eleifend molestie. Maecenas rutrum eros urna, eu sollicitudin elit viverra eu. Donec sollicitudin rhoncus lacus, euismod suscipit est accumsan id. ', 'Ator 02', 'Diretor 02', 'Bilheteria 02', 'https://static1.squarespace.com/static/54e6020ee4b0df3d2d8e6adb/t/5505f8f1e4b0147d505bbeab/1426454772902/cottage_fall2_banner.jpg'),
(4, 'Filme 03', '20122017', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur congue nisi id euismod pretium. Aliquam consequat purus eget nisl eleifend molestie. Maecenas rutrum eros urna, eu sollicitudin elit viverra eu. Donec sollicitudin rhoncus lacus, euismod suscipit est accumsan id. ', 'Ator 03', 'Diretor 03', 'Bilheteria 03', 'https://static1.squarespace.com/static/54e6020ee4b0df3d2d8e6adb/t/5505f8f1e4b0147d505bbeab/1426454772902/cottage_fall2_banner.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `filmes`
--
ALTER TABLE `filmes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `filmes`
--
ALTER TABLE `filmes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
