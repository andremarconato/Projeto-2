<?php include('header.php'); ?>
		
		<div id="corpo">
			<div class="top-body">
				<h1 class="titulo">Filmes mais assistidos:</h1>
			</div>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			<?php
			include('conexao.php'); 
			
			$sql = "SELECT * FROM filmes ";
			$result = mysqli_query($conn, $sql);
			
			if (mysqli_num_rows($result) > 0) {
			    // output data of each row
			    while($row = mysqli_fetch_assoc($result)){
			       ?>
			       
			        <div class="box-filme grid">
					<img class="img-filme" src="<?php echo $row['imagem']; ?>">
					
					<div class="nome-filme">
						<h2 class="nome"><?php echo $row['nome']; ?></h2>
					</div>
					<div class="ano-filme">
						<p class="ano"><?php echo substr($row['lancamento'],4,4); ?></<p>
					</div>
					
					<div class="clear"></div>
					
					<div class="descricao-filme">
						<p><?php echo $row['descricao']; ?></p>
					</div>
					
					<div class="bt-filme">
						<a class="botao" href="detalhes.php?id=<?php echo $row['id']; ?>">LEIA MAIS</a>
					</div>
					
				</div>
			      
			<?php
			}
			   
			} else {
			    echo "0 results";
			}
			
						
			mysqli_close($conn);
			?>



			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		</div>
		
	</div>
  </div>
  
</body>
</html>